﻿CLL MESDP Ticketing Worklog - Portable Build

Run:
  MESDP Scheduler Control.exe

Notes:
  - This package intentionally does not include app_config.json, tokens, passwords, logs, or preview reports.
  - First-run setup is stored per user under %APPDATA%\CLL MESDP\app_config.json.
  - The background scheduler is launched by start_scheduler.ps1 using MESDP Worklog Reminder.exe.
